﻿namespace finalSDP.scripts.Adapters;

public enum InputDevice
{
    Keyboard,GamePad
}