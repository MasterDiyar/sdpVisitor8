using System;

namespace finalSDP.scripts.Adapters;
using Godot;

public partial class MovementAdapter : Control
{
    public IDecorator current;
    private readonly KeyBordAdapter kb = new();
    private readonly GamePadAdapter pad = new();
    
    public void SetDevice(InputDevice device)
    {
        switch (device)
        { 
            case InputDevice.GamePad:
                current = pad;
                GD.Print("GamePad");
                break;
            case InputDevice.Keyboard:
                current = kb;
                GD.Print("KeyBord");
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(device), device, null);
        }
    }
}