namespace finalSDP.scripts.factories;

public class WeaponFactory
{
    
}